#!/bin/bash
set -euo pipefail

echo "🛡️ 生成 Nexus Swarm mTLS 憑證 (v22/v24 Spec)..."

# 1. 確保目錄存在
mkdir -p nexus-swarm/certs
cd nexus-swarm/certs

# 2. 生成 CA (根憑證)
if [ ! -f ca.key ]; then
    echo "🔒 Generating Root CA..."
    openssl req -x509 -newkey rsa:4096 -keyout ca.key -out ca.crt -days 3650 \
      -nodes -subj "/C=TW/ST=Taipei/L=NewTaipei/O=Nexus/CN=nexus-ca" \
      -addext "keyUsage=keyCertSign" \
      -addext "extendedKeyUsage=serverAuth,clientAuth"
fi

# 3. 生成 Manager 憑證
echo "🔒 Generating Swarm Manager Certificate..."
openssl req -newkey rsa:4096 -keyout manager.key -out manager.csr -nodes \
  -subj "/C=TW/ST=Taipei/L=NewTaipei/O=Nexus/CN=manager.nexus.local"

openssl x509 -req -in manager.csr -CA ca.crt -CAkey ca.key \
  -CAcreateserial -out manager.crt -days 365 \
  -extensions v3_req -extfile <(cat <<EOF
[v3_req]
basicConstraints=CA:FALSE
keyUsage=digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth,clientAuth
subjectAltName=DNS:manager.nexus.local,DNS:localhost,IP:127.0.0.1
EOF
)

# 4. 生成 Node 憑證 (通配符支援)
echo "🔒 Generating Swarm Node Certificate..."
openssl req -newkey rsa:4096 -keyout node.key -out node.csr -nodes \
  -subj "/C=TW/ST=Taipei/L=NewTaipei/O=Nexus/CN=node.nexus.local"

openssl x509 -req -in node.csr -CA ca.crt -CAkey ca.key \
  -CAcreateserial -out node.crt -days 365 \
  -extensions v3_req -extfile <(cat <<EOF
[v3_req]
basicConstraints=CA:FALSE
keyUsage=digitalSignature,keyEncipherment
extendedKeyUsage=clientAuth,serverAuth
subjectAltName=DNS:*.node.nexus.local,DNS:localhost,IP:127.0.0.1
EOF
)

chmod 600 *.key
echo "✅ mTLS 憑證生成完成內容與性能內容性能成果："
echo "  CA: ca.crt / ca.key"
echo "  Manager: manager.crt / manager.key"
echo "  Node: node.crt / node.key"
